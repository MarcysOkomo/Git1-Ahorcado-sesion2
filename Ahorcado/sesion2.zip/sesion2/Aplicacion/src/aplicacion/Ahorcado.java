
package aplicacion;

import java.util.Scanner;

/**
 *
 * @author marcys-okomo
 */
public class Ahorcado 
{
    int intentos = 6;
     String palabra[],
             elquearbitra;

    public Ahorcado(int intentos)
    {
        this.intentos = intentos;
    }
     
    Scanner sn = new Scanner(System.in);
    public void juegar()
    {
        String vista="";
         Scanner sn = new Scanner(System.in);
        System.out.print("Inserte la palabra a jugar:_");
        elquearbitra = sn.nextLine();
        
        System.out.println("La palabra a jugar tiene " + elquearbitra.length()+ " letras.");
        palabra = new String[elquearbitra.length()];
       
        
        for (int i = 0; i < elquearbitra.length(); i++)vista+="*";
            
       
        
        while(true)
        {
            System.out.println("");
            System.out.println(vista); 
            System.out.print("Adivine una letra:_");
            String adivino = sn.nextLine();
            
            String []cadena = elquearbitra.split("");
            int indice = 0;
            boolean encontrado = false;
            for(String le : cadena)
            {
                if(le.equals(adivino))
                {
                    palabra[indice] = le;
                    encontrado = true;
                }
                indice++;
            }
            
            if(encontrado) System.out.println("Vas bien, has acertado la letra\n\t\tTe quedan " + intentos + " intentos");
            else
            {
                intentos--;
                System.out.println("Mal asunto, Fallo. Debes completarla.");
                if(intentos == 0){
                    System.out.println("Se acabaron los intentos. \t Lo siento. Te has quedado ahorcado x(");
                    break;
                }
                else System.out.println("Te quedan " + intentos +" en total");
            }
            
            System.out.print("Por ahora tu juego va: ");
            imprimir(palabra);
            indice = 0;
            encontrado=false;
            if(elResultado(palabra))
            {
                System.out.println("\n\n\tEnhorabuena. Has completado la palabra");
                break;
            }
        }
        
    }
    public void imprimir(String [] palabra)
    {
        for(String le : palabra)
            if(le != null)System.out.print(le);   
            else System.out.print("-");
                
    }
    public boolean elResultado(String[] palabra)
    {
        for(String l: palabra)
            if(l == null)
                return false;
        return true;
    }
}
