package aplicacion;

import java.util.Scanner;

/**
 *
 * @author marcys-okomo
 */
public class Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        System.out.println("...Bienvenido a la APP del AHORCADO...");

        int quierojugar;

        do {
            System.out.println("1.- Jugar al ahorcado");
            System.out.println("2.-No quiero seguir jugando");
            System.out.print("\nElige opcion:_");
            quierojugar = sn.nextInt();
            switch (quierojugar) {
                case 1:
                    System.out.println("Inserte la cantidad de intentos del jugador/palabra");
                    int intentos;
                    Ahorcado jugar = new Ahorcado(intentos = sn.nextInt());
                    jugar.juegar();
                    break;
                case 2:
                    break;
            }

        } while (quierojugar != 2);

    }

}
